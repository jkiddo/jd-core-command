package jd.ide.eclipse.startup;

import org.eclipse.ui.IStartup;

/**
 * JDStartupClass
 * 
 * @project Java Decompiler Eclipse Plugin
 * @author  Emmanuel Dupuy
 * @version 0.1.3
 */
public class JDStartupClass implements IStartup
{
	public void earlyStartup() {}
}
